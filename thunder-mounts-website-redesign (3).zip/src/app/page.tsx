import { redirect } from "next/navigation";

// The proposal package (presentation, interactive demo, admin demo and documentation)
// is a self-contained static site served from /public/thunder-mounts-proposal so it can
// also be opened directly from disk or published to GitHub Pages without a build step.
export default function HomePage() {
  redirect("/thunder-mounts-proposal/index.html");
}
